//
//  EventsViewModel.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import Foundation

struct EventsViewModel {}
