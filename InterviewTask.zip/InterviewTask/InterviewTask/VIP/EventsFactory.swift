//
//  EventsFactory.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import Foundation

enum EventsFactory {

    static func makeScene() -> EventsViewController {
        let vc = EventsViewController(nibName: String(describing: EventsViewController.self), bundle: .main)
        let presenter = EventsPresenter(view: vc)
        let worker = EventsWorker()
        let interactor = EventsInteractor(presenter: presenter, worker: worker)
        let router = EventsRouter()
        router.bind(to: vc)
        vc.bind(to: interactor, and: router)
        return vc
    }
}
