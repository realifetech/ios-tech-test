//
//  EventsInteractor.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import Foundation

protocol EventsInteractable {
    // Replaced by view's output functions
}

final class EventsInteractor {

    private let presenter: EventsPresentable
    private let worker: EventsWorkable

    init(presenter: EventsPresentable, worker: EventsWorkable) {
        self.presenter = presenter
        self.worker = worker
    }
}

extension EventsInteractor: EventsInteractable {}
