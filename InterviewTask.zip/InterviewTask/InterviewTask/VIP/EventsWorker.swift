//
//  EventsWorker.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import Foundation

protocol EventsWorkable {}

final class EventsWorker {

    init() {}
}

extension EventsWorker: EventsWorkable {}
