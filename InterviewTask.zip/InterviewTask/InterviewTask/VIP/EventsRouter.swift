//
//  EventsRouter.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
// 
//

import UIKit

protocol EventsRoutable {}

final class EventsRouter {

    private weak var vc: UIViewController?

    func bind(to vc: UIViewController?) {
        self.vc = vc
    }
}

extension EventsRouter: EventsRoutable {}
