//
//  EventsPresenter.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import UIKit

protocol EventsPresentable: class {
    // Replaced by interactor's display output functions
}

final class EventsPresenter {

    private weak var view: EventsViewable?

    init(view: EventsViewable?) {
        self.view = view
    }
}

extension EventsPresenter: EventsPresentable {}
