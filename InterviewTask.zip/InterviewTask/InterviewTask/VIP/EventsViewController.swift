//
//  EventsViewController.swift
//  InterviewTask
//
//  Created by Mickey Lee on 27/11/2020.
//  
//

import UIKit
import Combine

protocol EventsViewable: class {
    // Replaced by presenter's presentation output functions
}

final class EventsViewController: UIViewController {

    private var interactor: EventsInteractable?
    private var router: EventsRoutable?
    private var disposables = Set<AnyCancellable>()

    override func viewDidLoad() {
        super.viewDidLoad()
        example()
    }

    func bind(to interactor: EventsInteractable?, and router: EventsRoutable) {
        self.interactor = interactor
        self.router = router
    }

    // NOTE: Example of subscribing EventProviding to make the API call
    // HINT: This function should NOT be handled in the view controller
    func example() {
        EventRepository().items(forPage: 0)
            .subscribe(on: DispatchQueue.global(qos: .background))
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completed in
                switch completed {
                case let .failure(error):
                    print("error: \(error)")
                case .finished:
                    print("finished")
                    break
                }
            }, receiveValue: { value in
                print(value)
            })
            .store(in: &disposables)
    }
}

extension EventsViewController: EventsViewable {}
