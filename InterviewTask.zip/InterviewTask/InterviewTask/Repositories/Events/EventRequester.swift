//
//  EventRequester.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

struct EventRequester: Requestable {

    var baseUrl: RequestBaseUrl = RequestBaseUrl.events
    var endpoint: String = "events"

    func items(forPage page: Int) -> URLRequest? {
        return createRequest(method: .GET, body: ["page": String(page)])
    }
}
