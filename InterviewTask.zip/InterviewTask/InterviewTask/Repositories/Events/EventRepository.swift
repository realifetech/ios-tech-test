//
//  EventRepository.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation
import Combine

protocol EventProvidable {
    func items(forPage page: Int) -> AnyPublisher<EventsResponse, EventsError>
}

struct EventRepository: Retrievable {
    typealias Cdble = EventsResponse
    typealias Rqstr = EventRequester
}

extension EventRepository: EventProvidable {

    func items(forPage page: Int) -> AnyPublisher<Cdble, EventsError> {
        return Retriever().retrieve(type: Cdble.self, forRequest: Rqstr().items(forPage: page))
    }
}
