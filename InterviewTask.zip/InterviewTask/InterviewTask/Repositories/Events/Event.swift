//
//  Event.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

struct EventsResponse: Codable {
    let page: Int
    let pageSize: Int
    let total: Int
    let items: [Event]
}

struct Event: Codable {
    let id: String
    let title: String
    let image: String
    let startDate: Int
}

extension Event {

    var userDefault: UserDefaults {
        return UserDefaults.standard
    }

    var isFavourite: Bool {
        return userDefault.bool(forKey: id)
    }

    func updateIsFavouriteState(_ state: Bool) {
        userDefault.set(state, forKey: id)
    }
}
