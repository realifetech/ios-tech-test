//
//  RequestBaseUrl.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

enum RequestBaseUrl: String {
    case events = "https://us-central1-techtaskapi.cloudfunctions.net/"
}
