//
//  Retrievable.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

protocol Retrievable {
    associatedtype Cdble = Codable
    associatedtype Rqstr = Requestable
}
