//
//  EventsError.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

enum EventsErrorType: Int {
    case noConnection
    case construct
    case custom
}

final class EventsError: Error {

    let type: EventsErrorType
    let title: String
    let message: String

    private init(type: EventsErrorType, title: String, message: String) {
        self.type = type
        self.title = title
        self.message = message
    }

    static func noConnectionError() -> EventsError {
        return EventsError(
            type: .noConnection,
            title: "No Connection",
            message: "Please check your internet connection and try again later.")
    }

    static func constructError(_ error: Error) -> EventsError {
        return EventsError(
            type: .construct,
            title: "Error",
            message: error.localizedDescription)
    }

    static func customError(title: String, message: String) -> EventsError {
        return EventsError(
            type: .custom,
            title: title,
            message: message)
    }
}
