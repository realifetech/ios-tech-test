//
//  HTTPMethod.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

enum HTTPMethod: String {
    case GET, POST, PUT, DELETE
}
