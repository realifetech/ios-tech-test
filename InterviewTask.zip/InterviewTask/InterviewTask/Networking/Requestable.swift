//
//  Requestable.swift
//  EventsTask
//
//  Created by Mickey Lee on 07/11/2020.
//

import Foundation

protocol Requestable {
    var baseUrl: RequestBaseUrl { get set }
    var endpoint: String { get set }
}

extension Requestable {

    var path: String {
        return baseUrl.rawValue + endpoint
    }

    func createRequest(method: HTTPMethod, headers: [String: String]? = nil, body: [String: Any]? = nil) -> URLRequest? {
        guard
            var urlComponents = URLComponents(string: path),
            let url = urlComponents.url
        else {
            return nil
        }

        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue

        if let headers = headers {
            request.allHTTPHeaderFields = headers
        }

        if let body = body {
            urlComponents.queryItems = makeQueryItems(for: method, with: body)
            request.httpBody = makeBodyData(for: method, with: body)
        }

        request.url = urlComponents.url
        return request
    }

    private func makeQueryItems(for method: HTTPMethod, with body: [String: Any]) -> [URLQueryItem] {
        switch method {
        case .GET:
            guard let body = body as? [String: String] else { return [] }
            return body.map { (key, value) in
                return URLQueryItem(name: key, value: value)
            }
        default:
            return []
        }
    }

    private func makeBodyData(for method: HTTPMethod, with body: [String: Any]) -> Data? {
        switch method {
        case .GET:
            return nil
        default:
            return try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
        }
    }
}
