//
//  Retriever.swift
//  EventsTask
//
//  Created by Mickey Lee on 16/11/2020.
//

import Foundation
import Combine

struct Retriever {

    let session: URLSession

    init(session: URLSession = URLSession.shared) {
        self.session = session
    }

    func retrieve<Type: Codable>(type: Type.Type, forRequest request: URLRequest?) -> AnyPublisher<Type, EventsError> {
        guard let returnedRequest = request else {
            return Fail(error: EventsError.customError(title: "Error", message: "Cannot get the request"))
                .eraseToAnyPublisher()
        }
        return remote(type: type, forRequest: returnedRequest)
            .eraseToAnyPublisher()
    }

    private func remote<Type: Codable>(type: Type.Type,  forRequest request: URLRequest) -> AnyPublisher<Type, EventsError> {
        return session.dataTaskPublisher(for: request)
            .mapError { error in
                EventsError.constructError(error)
            }
            .flatMap(maxPublishers: .max(1)) { pair -> AnyPublisher<Type, EventsError> in
                return decode(type: type, data: pair.data)
            }
            .eraseToAnyPublisher()
    }

    private func decode<Type: Codable>(type: Type.Type, data: Data) -> AnyPublisher<Type, EventsError> {
        return Just(data)
            .decode(type: type, decoder: JSONDecoder())
            .mapError { error in
                EventsError.constructError(error)
            }
            .eraseToAnyPublisher()
    }
}
